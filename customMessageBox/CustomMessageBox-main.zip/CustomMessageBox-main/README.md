# CustomMessageBox
Custom MessageBox - C# &amp; Windows Forms
<h2>VIDEO:</h2>
<a href="https://youtu.be/XWM0VnTXksY" target="_blank">
  <img src="https://rjcodeadvance.com/wp-content/uploads/2021/12/Custom-MessageBox-WinForm.jpg"/>
</a>
