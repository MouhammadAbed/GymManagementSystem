﻿
namespace CustomMessageBox
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnMsgText = new System.Windows.Forms.Button();
            this.btnMsgTextCaption1 = new System.Windows.Forms.Button();
            this.btnMsgOk = new System.Windows.Forms.Button();
            this.btnMsgQuestion = new System.Windows.Forms.Button();
            this.btnMsgButton1 = new System.Windows.Forms.Button();
            this.btnMsgButton2 = new System.Windows.Forms.Button();
            this.btnMsgButton3 = new System.Windows.Forms.Button();
            this.btnMsgWarning = new System.Windows.Forms.Button();
            this.btnMsgError = new System.Windows.Forms.Button();
            this.btnMsgInformation = new System.Windows.Forms.Button();
            this.btnMsgOkCancel = new System.Windows.Forms.Button();
            this.btnMsgYesNo = new System.Windows.Forms.Button();
            this.btnMsgAbortRetryIgnore = new System.Windows.Forms.Button();
            this.btnMsgYesNoCancel = new System.Windows.Forms.Button();
            this.btnMsgTextCaption2 = new System.Windows.Forms.Button();
            this.btnMsgRetryCancel = new System.Windows.Forms.Button();
            this.labelDialogResult = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.label5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgText, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgTextCaption1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgOk, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgQuestion, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgButton1, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgButton2, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgButton3, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgWarning, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgError, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgInformation, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgAbortRetryIgnore, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgOkCancel, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgYesNo, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgYesNoCancel, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgTextCaption2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnMsgRetryCancel, 2, 6);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1284, 520);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.SlateGray;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(1024, 0);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(260, 70);
            this.label5.TabIndex = 4;
            this.label5.Text = "Text | Caption | Buttons | Icon | Default Button";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(768, 0);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(256, 70);
            this.label4.TabIndex = 3;
            this.label4.Text = "Text | Caption | Buttons | Icon";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(512, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(256, 70);
            this.label3.TabIndex = 2;
            this.label3.Text = "Text | Caption | Buttons";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.PaleVioletRed;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(256, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(256, 70);
            this.label2.TabIndex = 1;
            this.label2.Text = "Text | Caption";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(256, 70);
            this.label1.TabIndex = 0;
            this.label1.Text = "Text";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnMsgText
            // 
            this.btnMsgText.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnMsgText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgText.FlatAppearance.BorderSize = 0;
            this.btnMsgText.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgText.ForeColor = System.Drawing.Color.White;
            this.btnMsgText.Location = new System.Drawing.Point(15, 85);
            this.btnMsgText.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgText.Name = "btnMsgText";
            this.btnMsgText.Size = new System.Drawing.Size(226, 45);
            this.btnMsgText.TabIndex = 5;
            this.btnMsgText.Text = "Text Message Only";
            this.btnMsgText.UseVisualStyleBackColor = false;
            this.btnMsgText.Click += new System.EventHandler(this.btnMsgText_Click);
            // 
            // btnMsgTextCaption1
            // 
            this.btnMsgTextCaption1.BackColor = System.Drawing.Color.Tomato;
            this.btnMsgTextCaption1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgTextCaption1.FlatAppearance.BorderSize = 0;
            this.btnMsgTextCaption1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgTextCaption1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgTextCaption1.ForeColor = System.Drawing.Color.White;
            this.btnMsgTextCaption1.Location = new System.Drawing.Point(271, 85);
            this.btnMsgTextCaption1.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgTextCaption1.Name = "btnMsgTextCaption1";
            this.btnMsgTextCaption1.Size = new System.Drawing.Size(226, 45);
            this.btnMsgTextCaption1.TabIndex = 6;
            this.btnMsgTextCaption1.Text = "Example 1";
            this.btnMsgTextCaption1.UseVisualStyleBackColor = false;
            this.btnMsgTextCaption1.Click += new System.EventHandler(this.btnMsgTextCaption1_Click);
            // 
            // btnMsgOk
            // 
            this.btnMsgOk.BackColor = System.Drawing.Color.SeaGreen;
            this.btnMsgOk.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgOk.FlatAppearance.BorderSize = 0;
            this.btnMsgOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgOk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgOk.ForeColor = System.Drawing.Color.White;
            this.btnMsgOk.Location = new System.Drawing.Point(527, 85);
            this.btnMsgOk.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgOk.Name = "btnMsgOk";
            this.btnMsgOk.Size = new System.Drawing.Size(226, 45);
            this.btnMsgOk.TabIndex = 7;
            this.btnMsgOk.Text = "Ok Button";
            this.btnMsgOk.UseVisualStyleBackColor = false;
            this.btnMsgOk.Click += new System.EventHandler(this.btnMsgOk_Click);
            // 
            // btnMsgQuestion
            // 
            this.btnMsgQuestion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(119)))), ((int)(((byte)(232)))));
            this.btnMsgQuestion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgQuestion.FlatAppearance.BorderSize = 0;
            this.btnMsgQuestion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgQuestion.ForeColor = System.Drawing.Color.White;
            this.btnMsgQuestion.Location = new System.Drawing.Point(783, 85);
            this.btnMsgQuestion.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgQuestion.Name = "btnMsgQuestion";
            this.btnMsgQuestion.Size = new System.Drawing.Size(226, 45);
            this.btnMsgQuestion.TabIndex = 8;
            this.btnMsgQuestion.Text = "Question Icon";
            this.btnMsgQuestion.UseVisualStyleBackColor = false;
            this.btnMsgQuestion.Click += new System.EventHandler(this.btnMsgQuestion_Click);
            // 
            // btnMsgButton1
            // 
            this.btnMsgButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnMsgButton1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgButton1.FlatAppearance.BorderSize = 0;
            this.btnMsgButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgButton1.ForeColor = System.Drawing.Color.White;
            this.btnMsgButton1.Location = new System.Drawing.Point(1039, 85);
            this.btnMsgButton1.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgButton1.Name = "btnMsgButton1";
            this.btnMsgButton1.Size = new System.Drawing.Size(230, 45);
            this.btnMsgButton1.TabIndex = 9;
            this.btnMsgButton1.Text = "Default Button 1";
            this.btnMsgButton1.UseVisualStyleBackColor = false;
            this.btnMsgButton1.Click += new System.EventHandler(this.btnMsgButton1_Click);
            // 
            // btnMsgButton2
            // 
            this.btnMsgButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnMsgButton2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgButton2.FlatAppearance.BorderSize = 0;
            this.btnMsgButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgButton2.ForeColor = System.Drawing.Color.White;
            this.btnMsgButton2.Location = new System.Drawing.Point(1039, 160);
            this.btnMsgButton2.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgButton2.Name = "btnMsgButton2";
            this.btnMsgButton2.Size = new System.Drawing.Size(230, 45);
            this.btnMsgButton2.TabIndex = 10;
            this.btnMsgButton2.Text = "Default Button 2";
            this.btnMsgButton2.UseVisualStyleBackColor = false;
            this.btnMsgButton2.Click += new System.EventHandler(this.btnMsgButton2_Click);
            // 
            // btnMsgButton3
            // 
            this.btnMsgButton3.BackColor = System.Drawing.Color.Gray;
            this.btnMsgButton3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgButton3.FlatAppearance.BorderSize = 0;
            this.btnMsgButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgButton3.ForeColor = System.Drawing.Color.White;
            this.btnMsgButton3.Location = new System.Drawing.Point(1039, 235);
            this.btnMsgButton3.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgButton3.Name = "btnMsgButton3";
            this.btnMsgButton3.Size = new System.Drawing.Size(230, 45);
            this.btnMsgButton3.TabIndex = 11;
            this.btnMsgButton3.Text = "Default Button 3";
            this.btnMsgButton3.UseVisualStyleBackColor = false;
            this.btnMsgButton3.Click += new System.EventHandler(this.btnMsgButton3_Click);
            // 
            // btnMsgWarning
            // 
            this.btnMsgWarning.BackColor = System.Drawing.Color.DarkOrange;
            this.btnMsgWarning.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgWarning.FlatAppearance.BorderSize = 0;
            this.btnMsgWarning.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgWarning.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgWarning.ForeColor = System.Drawing.Color.White;
            this.btnMsgWarning.Location = new System.Drawing.Point(783, 160);
            this.btnMsgWarning.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgWarning.Name = "btnMsgWarning";
            this.btnMsgWarning.Size = new System.Drawing.Size(226, 45);
            this.btnMsgWarning.TabIndex = 12;
            this.btnMsgWarning.Text = "Exclamation - Warning";
            this.btnMsgWarning.UseVisualStyleBackColor = false;
            this.btnMsgWarning.Click += new System.EventHandler(this.btnMsgWarning_Click);
            // 
            // btnMsgError
            // 
            this.btnMsgError.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(79)))), ((int)(((byte)(95)))));
            this.btnMsgError.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgError.FlatAppearance.BorderSize = 0;
            this.btnMsgError.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgError.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgError.ForeColor = System.Drawing.Color.White;
            this.btnMsgError.Location = new System.Drawing.Point(783, 235);
            this.btnMsgError.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgError.Name = "btnMsgError";
            this.btnMsgError.Size = new System.Drawing.Size(226, 45);
            this.btnMsgError.TabIndex = 13;
            this.btnMsgError.Text = "Error - Stop";
            this.btnMsgError.UseVisualStyleBackColor = false;
            this.btnMsgError.Click += new System.EventHandler(this.btnMsgError_Click);
            // 
            // btnMsgInformation
            // 
            this.btnMsgInformation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(191)))), ((int)(((byte)(166)))));
            this.btnMsgInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgInformation.FlatAppearance.BorderSize = 0;
            this.btnMsgInformation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgInformation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgInformation.ForeColor = System.Drawing.Color.White;
            this.btnMsgInformation.Location = new System.Drawing.Point(783, 310);
            this.btnMsgInformation.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgInformation.Name = "btnMsgInformation";
            this.btnMsgInformation.Size = new System.Drawing.Size(226, 45);
            this.btnMsgInformation.TabIndex = 14;
            this.btnMsgInformation.Text = "Information";
            this.btnMsgInformation.UseVisualStyleBackColor = false;
            this.btnMsgInformation.Click += new System.EventHandler(this.btnMsgInformation_Click);
            // 
            // btnMsgOkCancel
            // 
            this.btnMsgOkCancel.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnMsgOkCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgOkCancel.FlatAppearance.BorderSize = 0;
            this.btnMsgOkCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgOkCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgOkCancel.ForeColor = System.Drawing.Color.White;
            this.btnMsgOkCancel.Location = new System.Drawing.Point(527, 160);
            this.btnMsgOkCancel.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgOkCancel.Name = "btnMsgOkCancel";
            this.btnMsgOkCancel.Size = new System.Drawing.Size(226, 45);
            this.btnMsgOkCancel.TabIndex = 15;
            this.btnMsgOkCancel.Text = "Ok - Cancel";
            this.btnMsgOkCancel.UseVisualStyleBackColor = false;
            this.btnMsgOkCancel.Click += new System.EventHandler(this.btnMsgOkCancel_Click);
            // 
            // btnMsgYesNo
            // 
            this.btnMsgYesNo.BackColor = System.Drawing.Color.MediumOrchid;
            this.btnMsgYesNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgYesNo.FlatAppearance.BorderSize = 0;
            this.btnMsgYesNo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgYesNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgYesNo.ForeColor = System.Drawing.Color.White;
            this.btnMsgYesNo.Location = new System.Drawing.Point(527, 310);
            this.btnMsgYesNo.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgYesNo.Name = "btnMsgYesNo";
            this.btnMsgYesNo.Size = new System.Drawing.Size(226, 45);
            this.btnMsgYesNo.TabIndex = 16;
            this.btnMsgYesNo.Text = "Yes - No";
            this.btnMsgYesNo.UseVisualStyleBackColor = false;
            this.btnMsgYesNo.Click += new System.EventHandler(this.btnMsgYesNo_Click);
            // 
            // btnMsgAbortRetryIgnore
            // 
            this.btnMsgAbortRetryIgnore.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btnMsgAbortRetryIgnore.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgAbortRetryIgnore.FlatAppearance.BorderSize = 0;
            this.btnMsgAbortRetryIgnore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgAbortRetryIgnore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgAbortRetryIgnore.ForeColor = System.Drawing.Color.White;
            this.btnMsgAbortRetryIgnore.Location = new System.Drawing.Point(527, 235);
            this.btnMsgAbortRetryIgnore.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgAbortRetryIgnore.Name = "btnMsgAbortRetryIgnore";
            this.btnMsgAbortRetryIgnore.Size = new System.Drawing.Size(226, 45);
            this.btnMsgAbortRetryIgnore.TabIndex = 17;
            this.btnMsgAbortRetryIgnore.Text = "Abort - Retry - Ignore";
            this.btnMsgAbortRetryIgnore.UseVisualStyleBackColor = false;
            this.btnMsgAbortRetryIgnore.Click += new System.EventHandler(this.btnMsgAbortRetryIgnore_Click);
            // 
            // btnMsgYesNoCancel
            // 
            this.btnMsgYesNoCancel.BackColor = System.Drawing.Color.BlueViolet;
            this.btnMsgYesNoCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgYesNoCancel.FlatAppearance.BorderSize = 0;
            this.btnMsgYesNoCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgYesNoCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgYesNoCancel.ForeColor = System.Drawing.Color.White;
            this.btnMsgYesNoCancel.Location = new System.Drawing.Point(527, 385);
            this.btnMsgYesNoCancel.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgYesNoCancel.Name = "btnMsgYesNoCancel";
            this.btnMsgYesNoCancel.Size = new System.Drawing.Size(226, 45);
            this.btnMsgYesNoCancel.TabIndex = 18;
            this.btnMsgYesNoCancel.Text = "Yes - No - Cancel";
            this.btnMsgYesNoCancel.UseVisualStyleBackColor = false;
            this.btnMsgYesNoCancel.Click += new System.EventHandler(this.btnMsgYesNoCancel_Click);
            // 
            // btnMsgTextCaption2
            // 
            this.btnMsgTextCaption2.BackColor = System.Drawing.Color.SteelBlue;
            this.btnMsgTextCaption2.FlatAppearance.BorderSize = 0;
            this.btnMsgTextCaption2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgTextCaption2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgTextCaption2.ForeColor = System.Drawing.Color.White;
            this.btnMsgTextCaption2.Location = new System.Drawing.Point(271, 160);
            this.btnMsgTextCaption2.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgTextCaption2.Name = "btnMsgTextCaption2";
            this.btnMsgTextCaption2.Size = new System.Drawing.Size(226, 45);
            this.btnMsgTextCaption2.TabIndex = 19;
            this.btnMsgTextCaption2.Text = "Example 2";
            this.btnMsgTextCaption2.UseVisualStyleBackColor = false;
            this.btnMsgTextCaption2.Click += new System.EventHandler(this.btnMsgTextCaption2_Click);
            // 
            // btnMsgRetryCancel
            // 
            this.btnMsgRetryCancel.BackColor = System.Drawing.Color.SlateGray;
            this.btnMsgRetryCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMsgRetryCancel.FlatAppearance.BorderSize = 0;
            this.btnMsgRetryCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMsgRetryCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMsgRetryCancel.ForeColor = System.Drawing.Color.White;
            this.btnMsgRetryCancel.Location = new System.Drawing.Point(527, 460);
            this.btnMsgRetryCancel.Margin = new System.Windows.Forms.Padding(15);
            this.btnMsgRetryCancel.Name = "btnMsgRetryCancel";
            this.btnMsgRetryCancel.Size = new System.Drawing.Size(226, 45);
            this.btnMsgRetryCancel.TabIndex = 20;
            this.btnMsgRetryCancel.Text = "Retry - Cancel";
            this.btnMsgRetryCancel.UseVisualStyleBackColor = false;
            this.btnMsgRetryCancel.Click += new System.EventHandler(this.btnMsgRetryCancel_Click);
            // 
            // labelDialogResult
            // 
            this.labelDialogResult.BackColor = System.Drawing.Color.White;
            this.labelDialogResult.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.labelDialogResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDialogResult.ForeColor = System.Drawing.Color.DimGray;
            this.labelDialogResult.Location = new System.Drawing.Point(0, 542);
            this.labelDialogResult.Name = "labelDialogResult";
            this.labelDialogResult.Size = new System.Drawing.Size(1284, 60);
            this.labelDialogResult.TabIndex = 1;
            this.labelDialogResult.Text = "Dialog Result";
            this.labelDialogResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 602);
            this.Controls.Add(this.labelDialogResult);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Custom Message Box";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnMsgText;
        private System.Windows.Forms.Button btnMsgTextCaption1;
        private System.Windows.Forms.Button btnMsgOk;
        private System.Windows.Forms.Button btnMsgQuestion;
        private System.Windows.Forms.Button btnMsgButton1;
        private System.Windows.Forms.Button btnMsgButton2;
        private System.Windows.Forms.Button btnMsgButton3;
        private System.Windows.Forms.Button btnMsgWarning;
        private System.Windows.Forms.Button btnMsgError;
        private System.Windows.Forms.Button btnMsgInformation;
        private System.Windows.Forms.Button btnMsgAbortRetryIgnore;
        private System.Windows.Forms.Button btnMsgOkCancel;
        private System.Windows.Forms.Button btnMsgYesNo;
        private System.Windows.Forms.Button btnMsgYesNoCancel;
        private System.Windows.Forms.Button btnMsgTextCaption2;
        private System.Windows.Forms.Button btnMsgRetryCancel;
        private System.Windows.Forms.Label labelDialogResult;
    }
}